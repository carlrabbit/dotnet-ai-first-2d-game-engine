# Guide Sync Hint — Milestone 017 Index and Cross-Link Synchronization

## Status

Pending.

Synchronize animation content roots, validation commands, specs, artifacts, project shape, wrappers, M017, and ADR-0020 after implementation.

Delete when animation definitions, base/overlay sampling, markers, animated rendering, replay evidence, and headless validation are discoverable; raylib remains an adapter; and unsupported blending, skeletal animation, audio, particles, UI/editor, save/load, and packaging are not documented as current.
