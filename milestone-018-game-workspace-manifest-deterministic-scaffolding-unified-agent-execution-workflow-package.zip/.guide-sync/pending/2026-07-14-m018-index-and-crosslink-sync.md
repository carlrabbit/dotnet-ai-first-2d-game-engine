# Guide Sync Hint — Milestone 018 Index and Cross-Link Synchronization

## Status

Pending.

Synchronize workspace/project manifests, acquisition providers, scaffolding commands, generated workspace shape, unified run workflow, artifact contracts, ADR-0021, M018, project shape, validation tiers, and product CLI docs after implementation.

Delete when directory/Git acquisition, create/validate/run/inspect/review commands, run manifests, provider-consumer boundaries, and unsupported update/NuGet/portable-SDK status are discoverable from active project docs.
